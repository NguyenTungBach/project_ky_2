<?php if($paginator->hasPages()): ?>

    <!-- Prevoius Page Link -->
    <?php if($paginator->onFirstPage()): ?>
        <a class="paginate-previous disabled flex-c-m txt-s-115 cl6  how-btn1 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 p-b-1">
            Trước
        </a>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>"
           class="paginate-previous disabled flex-c-m txt-s-115 cl6  how-btn1 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 p-b-1">
            Trước
        </a>
    <?php endif; ?>

    <!-- Pagination Elements Here -->

    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Make three dots -->
        <?php if(is_string($element)): ?>
            <a  class="flex-c-m txt-s-115 cl6 size-a-23 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 disabled">
                <?php echo e($element); ?>

            </a>
        <?php endif; ?>

        <!-- Links Array Here -->
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page=>$url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                       class="flex-c-m txt-s-115 cl6 size-a-23 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 active-pagi1">
                        <?php echo e($page); ?>

                    </a>
                <?php else: ?>
                    <a href="<?php echo e($url); ?>"
                       class="flex-c-m txt-s-115 cl6 size-a-23 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3">
                        <?php echo e($page); ?>

                    </a>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Next Page Link -->
    <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>"
           class="flex-c-m txt-s-115 cl6 size-a-24 how-btn1 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 p-b-1">
            Tiếp
        </a>
    <?php else: ?>
        <a class="flex-c-m txt-s-115 cl6 size-a-24 how-btn1 bo-all-1 bocl15 hov-btn1 trans-04 m-all-3 p-b-1">
            Tiếp
        </a>
    <?php endif; ?>


<?php endif; ?>

<?php /**PATH F:\HocWeb\PHP\Bài Tập PHP\ProjectKy2\resources\views/client/include/pagination.blade.php ENDPATH**/ ?>