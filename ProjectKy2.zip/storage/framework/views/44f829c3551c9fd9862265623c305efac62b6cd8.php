<section class="how-overlay2 bg-img1" style="background-image: url(/client/images/bg-07.jpg);">
    <div class="container">
        <div class="txt-center p-t-160 p-b-165">
            <h2 class="txt-l-101 cl0 txt-center p-b-14 respon1">
                <?php echo e($title); ?>

            </h2>

            <span class="txt-m-201 cl0 flex-c-m flex-w">
					<a href="index.html" class="txt-m-201 cl0 hov-cl10 trans-04 m-r-6">
						Trang chủ
					</a>

					<span>
						/ <?php echo e($title); ?>

					</span>
				</span>
        </div>
    </div>
</section>
<?php /**PATH F:\HocWeb\PHP\Bài Tập PHP\ProjectKy2\resources\views/client/include/title-page.blade.php ENDPATH**/ ?>