<!--===============================================================================================-->
<script data-cfasync="false" src="/client/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="/client/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/bootstrap/js/popper.js"></script>
<script src="/client/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/daterangepicker/moment.min.js"></script>
<script src="/client/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/slick/slick.min.js"></script>
<script src="/client/js/slick-custom.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/parallax100/parallax100.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/isotope/isotope.pkgd.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/sweetalert/sweetalert.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/noui/nouislider.min.js"></script>
<!--===============================================================================================-->
<script src="/client/vendor/slide100/slide100.js"></script>
<script src="/client/js/slide100-custom.js"></script>
<!--Plugin JavaScript file-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/js/ion.rangeSlider.min.js"></script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v12.0" nonce="MVq2CUvy"></script>
