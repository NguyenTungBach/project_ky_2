<div class="sec-logo bg0">
    <div class="container">
        <div class="flex-w flex-sa-m bo-t-1 bocl13 p-tb-60">
            <a href="#" class="dis-block how2 p-rl-15 m-tb-20">
                <img class="trans-04" src="/client/images/icons/symbol-07.png" alt="IMG">
            </a>

            <a href="#" class="dis-block how2 p-rl-15 m-tb-20">
                <img class="trans-04" src="/client/images/icons/symbol-08.png" alt="IMG">
            </a>

            <a href="#" class="dis-block how2 p-rl-15 m-tb-20">
                <img class="trans-04" src="/client/images/icons/symbol-09.png" alt="IMG">
            </a>

            <a href="#" class="dis-block how2 p-rl-15 m-tb-20">
                <img class="trans-04" src="/client/images/icons/symbol-10.png" alt="IMG">
            </a>

            <a href="#" class="dis-block how2 p-rl-15 m-tb-20">
                <img class="trans-04" src="/client/images/icons/symbol-11.png" alt="IMG">
            </a>
        </div>
    </div>
</div>
